
<!-- All JS Files -->
<!-- jQuery -->
<script src="<?php echo base_url(); ?>assets/website/js/jquery.min.js"></script>
<!-- Popper -->
<script src="<?php echo base_url(); ?>assets/website/js/popper.min.js"></script>
<!-- Bootstrap -->
<script src="<?php echo base_url(); ?>assets/website/js/bootstrap.min.js"></script>
<!-- All Plugins -->
<script src="<?php echo base_url(); ?>assets/website/js/akame.bundle.js"></script>
<!-- Active -->
<script src="<?php echo base_url(); ?>assets/website/js/default-assets/active.js"></script>

<!--bootstrap admin panel js-->
<script src="<?php echo base_url(); ?>assets/js/adminjs/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo base_url(); ?>assets/js/adminjs/jquery.easing.min.js"></script>

<!-- Page level plugin JavaScript-->
<script src="<?php echo base_url(); ?>assets/js/adminjs/Chart.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/adminjs/jquery.dataTables.js"></script>
<script src="<?php echo base_url(); ?>assets/js/adminjs/dataTables.bootstrap4.js"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo base_url(); ?>assets/js/adminjs/sb-admin.min.js"></script>

<!-- Demo scripts for this page-->
<script src="<?php echo base_url(); ?>assets/js/adminjs/datatables-demo.js"></script>
<script src="<?php echo base_url(); ?>assets/js/adminjs/chart-area-demo.js"></script>

<!--bootstrap admin panel js ends-->
